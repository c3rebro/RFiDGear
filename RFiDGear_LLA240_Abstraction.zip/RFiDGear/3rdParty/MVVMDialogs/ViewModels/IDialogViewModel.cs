﻿using System.ComponentModel;

namespace MvvmDialogs.ViewModels
{
    public interface IDialogViewModel : INotifyPropertyChanged
    {
    }
}