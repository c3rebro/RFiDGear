﻿using System;
using System.Windows;

namespace RFiDGear
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        //		[STAThread]
        //		public static void Main()
        //		{
        //			var application = new App();
        //			//application.StartupUri = new Uri("pack://application:,,,/RFiDGear;component/App.xaml");
        //			application.Run();
        //		}
    }
}