﻿/*
 * Created by SharpDevelop.
 * Date: 10/10/2017
 * Time: 20:19
 *
 */

using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for TabPageReportSettingsView.xaml
    /// </summary>
    public partial class TabPageLogicTaskView : UserControl
    {
        public TabPageLogicTaskView()
        {
            InitializeComponent();
        }
    }
}