﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaktionslogik für AutoTextEditorView.xaml
    /// </summary>
    public partial class AutoTextEditorView : Window
    {
        public AutoTextEditorView()
        {
            InitializeComponent();
        }
    }
}
