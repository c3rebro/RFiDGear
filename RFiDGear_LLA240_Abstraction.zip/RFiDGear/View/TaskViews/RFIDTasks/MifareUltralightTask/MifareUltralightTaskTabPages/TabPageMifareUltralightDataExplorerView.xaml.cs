﻿/*
 * Created by SharpDevelop.
 * User: C3rebro
 * Date: 04/24/2018
 * Time: 23:38
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for TabPageMifareUltralightDataExplorerView.xaml
    /// </summary>
    public partial class TabPageMifareUltralightDataExplorerView : UserControl
    {
        public TabPageMifareUltralightDataExplorerView()
        {
            InitializeComponent();
        }
    }
}