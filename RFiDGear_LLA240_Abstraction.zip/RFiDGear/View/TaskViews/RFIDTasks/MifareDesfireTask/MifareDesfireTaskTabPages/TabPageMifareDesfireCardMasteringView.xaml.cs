﻿/*
 * Created by SharpDevelop.
 * Date: 10.10.2017
 * Time: 22:11
 *
 */

using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for MifareDesfireCardMasteringView.xaml
    /// </summary>
    public partial class TabPageMifareDesfireCardMasteringView : UserControl
    {
        public TabPageMifareDesfireCardMasteringView()
        {
            InitializeComponent();
        }
    }
}