﻿/*
 * Created by SharpDevelop.
 * Date: 10.10.2017
 * Time: 22:12
 *
 */

using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for MifareDesfireFileMasteringView.xaml
    /// </summary>
    public partial class TabPageMifareDesfireFileMasteringView : UserControl
    {
        public TabPageMifareDesfireFileMasteringView()
        {
            InitializeComponent();
        }
    }
}