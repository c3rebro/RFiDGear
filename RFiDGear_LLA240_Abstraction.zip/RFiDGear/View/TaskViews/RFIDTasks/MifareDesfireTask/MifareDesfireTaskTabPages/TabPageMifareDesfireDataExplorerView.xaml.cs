﻿/*
 * Created by SharpDevelop.
 * Date: 10.10.2017
 * Time: 22:13
 *
 */

using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for TabPageMifareDesfireDataExplorerView.xaml
    /// </summary>
    public partial class TabPageMifareDesfireDataExplorerView : UserControl
    {
        public TabPageMifareDesfireDataExplorerView()
        {
            InitializeComponent();
        }
    }
}