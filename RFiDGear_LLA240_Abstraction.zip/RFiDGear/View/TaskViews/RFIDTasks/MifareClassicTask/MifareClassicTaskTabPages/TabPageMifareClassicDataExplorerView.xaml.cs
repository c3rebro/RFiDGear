﻿/*
 * Created by SharpDevelop.
 * Date: 24.10.2017
 * Time: 16:00
 *
 */

using System.Windows.Controls;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for TabPageMifareClassicDataExplorerView.xaml
    /// </summary>
    public partial class TabPageMifareClassicDataExplorerView : UserControl
    {
        public TabPageMifareClassicDataExplorerView()
        {
            InitializeComponent();
        }
    }
}