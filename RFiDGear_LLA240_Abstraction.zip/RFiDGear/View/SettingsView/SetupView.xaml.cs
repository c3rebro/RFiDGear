﻿/*
 * Created by SharpDevelop.
 * Date: 10/10/2017
 * Time: 20:24
 *
 */

using System.Windows;

namespace RFiDGear.View
{
    /// <summary>
    /// Interaction logic for SetupDialogBoxView.xaml
    /// </summary>
    public partial class SetupView : Window
    {
        public SetupView()
        {
            InitializeComponent();
        }
    }
}