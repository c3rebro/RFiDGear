﻿/*
 * Created by SharpDevelop.
 * Date: 21.02.2018
 * Time: 08:59
 * 
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace RFiDGear.View
{
	/// <summary>
	/// Interaction logic for ProfileEditor.xaml
	/// </summary>
	public partial class CheckpointEditorView : Window
	{
		public CheckpointEditorView()
		{
			InitializeComponent();
		}
	}
}